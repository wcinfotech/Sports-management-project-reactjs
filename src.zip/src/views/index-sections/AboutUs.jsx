/*!

=========================================================
* Paper Kit React - v1.3.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-kit-react

* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/paper-kit-react/blob/main/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from "react";

// reactstrap components
import {
  UncontrolledCollapse,
  NavbarBrand,
  Navbar,
  NavItem,
  NavLink,
  Nav,
  Container,
} from "reactstrap";
import CarouselFun from "./carousel";

// core components

function AboutUs() {
  return (
    <>
      <div className="section section-navigation">
        <Container className="tim-container mt-5 mb-2">
          <h1 className="display-3 text-center">ABOUT US</h1>
          <hr class="my-4" />
          <div class="container">
            <div class="row">
              <div class="col-md">
                <CarouselFun />
              </div>
              <p class="lead mt-4">
                
              </p>
            </div>
          </div>
        </Container>
      </div>
    </>
  );
}

export default AboutUs;
