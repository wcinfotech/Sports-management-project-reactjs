import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch } from "react-router-dom";

import "bootstrap/scss/bootstrap.scss";
import "assets/scss/paper-kit.scss?v=1.3.0";
import "assets/demo/demo.css?v=1.3.0";
import Index from "views/Index.js";
import NucleoIcons from "views/NucleoIcons.js";
import LandingPage from "views/examples/LandingPage.js";
import ProfilePage from "views/examples/ProfilePage.js";
import RegisterPage from "views/examples/RegisterPage.js";
import App from "App";
import AboutUsPage from "AboutPage";
import ContactUsPage from "contactUsPage";
import Task from "Task";
import Auth from "Auth";
import Signin from "Sign";
import MoviesList from "MoviesList";


// others

// const root = ReactDOM.createRoot(document.getElementById("root"));

// root.render(
//   <BrowserRouter>
//     <Switch>
//       <Route path="/home" render={(props) => <App {...props} />} />
//       <Route path="/about" render={(props) => <AboutUsPage {...props} />} />
//       <Route path="/contact" render={(props) => <ContactUsPage {...props} />} />
//       <Route path="/task" render={(props) => <Task {...props} />} />
//       <Route path="/auth" render={(props) => <Auth {...props} />} />

      
     

//       <Route path="/index" render={(props) => <Index {...props} />} />
//       <Route
//         path="/nucleo-icons"
//         render={(props) => <NucleoIcons {...props} />}
//       />
//       <Route
//         path="/landing-page"
//         render={(props) => <LandingPage {...props} />}
//       />
//       <Route
//         path="/profile-page"
//         render={(props) => <ProfilePage {...props} />}
//       />
//       <Route
//         path="/register-page"
//         render={(props) => <RegisterPage {...props} />}
//       />
//       <Redirect to="/index" />
//     </Switch>
//   </BrowserRouter>
// );
ReactDOM.render(
  <BrowserRouter>
    <Switch>
      <Route path="/home" render={(props) => <App {...props} />} />
      <Route path="/about" render={(props) => <AboutUsPage {...props} />} />
      <Route path="/contact" render={(props) => <ContactUsPage {...props} />} />
      <Route path="/task" render={(props) => <Task {...props} />} />
      <Route path="/auth" render={(props) => <Auth {...props} />} />
      <Route path="/Signin" render={(props) => <Signin {...props} />} />
      

      
     

      {/* <Route path="/index" render={(props) => <Index {...props} />} /> */}
      <Route
        path="/nucleo-icons"
        render={(props) => <NucleoIcons {...props} />}
      />
      <Route
        path="/landing-page"
        render={(props) => <LandingPage {...props} />}
      />
      <Route
        path="/profile-page"
        render={(props) => <ProfilePage {...props} />}
      />
      <Route
        path="/register-page"
        render={(props) => <RegisterPage {...props} />}
      />
      <Redirect to="/home" />
    </Switch>
  </BrowserRouter>,
  document.getElementById('root')
);
