import React from "react";

// reactstrap components
import { Container } from "reactstrap";

// core components

function IndexHeader() {
  return (
    <>
      <div
        className="page-header section-dark"
        style={{
        backgroundImage: "url(" + require("assets/img/sports/sport.jpg") + ")",
        backgroundColor:"Purple",
         }}
      >
        <div className="filter" />
        <div className="content-center">
          <Container>
            <div className="title-brand">
              {/* <h4 className="presentation-title" style={{ fontSize: "4em" }}>
                BEST DEAL IN DIGITAL ITEMS ON LOW PRICES
              </h4> */}
              <div className="fog-low">
                <img alt="..." src={require("assets/img/fog-low.png")} />
              </div>
              <div className="fog-low right mt-4">
                <img alt="..." src={require("assets/img/fog-low.png")} />
              </div>
            </div>
            {/* <h2
              className="presentation-subtitle text-center"
              style={{ marginTop: "5rem" }}
            >
              Sports management
            </h2> */}
          </Container>
        </div>
        <div
          className="moving-clouds"
          style={{
            backgroundImage: "url(" + require("assets/img/clouds.png") + ")",
          }}
        />
        {/* <h6 className="category category-absolute">
          Designed and coded by{" "}
          
          <i className="fa fa-heart heart" /> by WC Team
        </h6> */}
      </div>
    </>
  );
}

export default IndexHeader;
