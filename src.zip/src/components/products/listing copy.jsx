import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Container,
  Row,
  Col,
  Popover,
  PopoverHeader,
  PopoverBody,
  Button,
  NavItem,
  NavLink,
  Nav,
  TabContent,
  TabPane,
} from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";
// import Pagination from "react-bootstrap/Pagination";
import { ProductList } from "./list.ts";
import Pagination from "react-js-pagination";
import TableBody from "./popupbody";
export default function Listing() {
  const [activeTab, setActiveTab] = React.useState("tv");
  const toggleTab = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };
  //   const [popOverOpen, SetPopOver] = useState(false);
  const [state, setState] = useState({
    data: ProductList,
    limit: 6,
    startIndex: 0,
    pageSize: ProductList.length / 3,
    activePage: 1,
  });

  const [currentData, setCurrentData] = useState([]);
  useEffect(() => {
    const data = [];

    ProductList.filter((item, index) => {
      //   console.log(index, state.limit);
      if (index >= state.startIndex && data.length < state.limit) {
        data.push(item);
      }
    });
    setCurrentData(data);
  }, []);
  useEffect(() => {}, [currentData]);

  function toggle(index) {
    const data = [...currentData];
    const set = data[index].popOverOpen;
    data[index].popOverOpen = !set;
    setCurrentData(data);
    // SetPopOver(!popOverOpen);
  }

  const onHover = (index) => {
    const data = [...currentData];
    data[index].popOverOpen = true;
    setCurrentData(data);
    // SetPopOver(true);
  };

  const onHoverLeave = (index) => {
    const data = [...currentData];
    data[index].popOverOpen = false;
    setCurrentData(data);
    // SetPopOver(false);
  };
  const handlePageChange = (pageNumber) => {
    let sindex = 0;
    if (pageNumber !== 1) sindex = (pageNumber - 1) * state.limit;
    else sindex = 0;

    const data = [];
    ProductList.map((item, index) => {
      if (index >= sindex && data.length < state.limit) {
        data.push(item);
      }
    });

    setState((prev) => ({
      ...prev,
      activePage: pageNumber,
      startIndex: sindex,
    }));
    setCurrentData(data);
  };
  const newwwww = ProductList.filter((element) => {
    return element.category === activeTab;
  });
  console.log("newww", newwwww);

  return (
    <div className="section section-navigation">
      <Container className="tim-container" fluid="md">
        {/* <h2 className="mt-5 px-4">React Bootstrap pagination example</h2> */}
        <Col md="12">
          <div className="title">
            <h3>Navigation Tabs</h3>
          </div>
          <div className="nav-tabs-navigation">
            <div className="nav-tabs-wrapper">
              <Nav id="tabs" role="tablist" tabs>
                <NavItem>
                  <NavLink
                    className={activeTab === "tv" ? "active" : ""}
                    onClick={() => {
                      toggleTab("tv");
                    }}
                  >
                    1
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "refrigrator" ? "active" : ""}
                    onClick={() => {
                      toggleTab("refrigrator");
                    }}
                  >
                    2
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "computer" ? "active" : ""}
                    onClick={() => {
                      toggleTab("computer");
                    }}
                  >
                    3
                  </NavLink>
                </NavItem>
              </Nav>
            </div>
          </div>
          <TabContent activeTab={activeTab} className="text-center">
            <TabPane tabId="1">
              <p>
                Larger, yet dramatically thinner. More powerful, but remarkably
                power efficient. With a smooth metal surface that seamlessly
                meets the new Retina HD display.
              </p>
            </TabPane>
            <TabPane tabId="2">
              <Row md="3" sm="2" xs="1">
                {currentData.map((item, index) => {
                  return (
                    <>
                      <Col>
                        <div
                          className="title shadow p-3 mb-5 border rounded-end rounded"
                          style={{ backgroundColor: "#d6d6d6" }}
                        >
                          {/* <h3>Navigation Areas</h3> */}
                          <Button
                            style={{
                              backgroundColor: "#d6d6d6",
                              border: "none",
                            }}
                            id={`btn-${item.id}`}
                            onMouseEnter={(e) => {
                              onHover(index);
                            }}
                            onMouseLeave={(e) => {
                              onHoverLeave(index);
                            }}
                          >
                            <div
                              class="card"
                              style={{ width: "12rem", display: "contents" }}
                            >
                              <img
                                src="https://images.unsplash.com/photo-1533228100845-08145b01de14?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=438&q=80"
                                class="card-img-top"
                                alt="..."
                              />
                              <div class="card-body">
                                <p class="card-text fw-bold">
                                  sport name
                                </p>
                              </div>
                            </div>{" "}
                          </Button>
                        </div>
                      </Col>
                      <Popover
                        placement="right"
                        target={`btn-${item.id}`}
                        isOpen={item.popOverOpen}
                        toggle={toggle}
                      >
                        <PopoverHeader>{item.name}</PopoverHeader>
                        <PopoverBody>
                          <TableBody />
                        </PopoverBody>
                      </Popover>
                    </>
                  );
                })}
              </Row>
            </TabPane>
            <TabPane tabId="3">
              <p>Here are your messages.</p>
            </TabPane>
          </TabContent>
        </Col>

        <div className="d-flex justify-content-center">
          <Pagination
            activePage={state.activePage}
            itemsCountPerPage={state.limit}
            totalItemsCount={ProductList.length}
            pageRangeDisplayed={ProductList.length / state.limit + 2}
            onChange={handlePageChange}
          />
        </div>
      </Container>
    </div>
  );
}
