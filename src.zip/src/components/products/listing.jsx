import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Container,
  Row,
  Col,
  Popover,
  PopoverHeader,
  PopoverBody,
  Button,
  NavItem,
  NavLink,
  Nav,
  TabContent,
  TabPane,
} from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
// import Pagination from "react-bootstrap/Pagination";
import { ProductList } from "./list.ts";
import Pagination from "react-js-pagination";
import TableBody from "./popupbody";
export default function Listing() {
  const [activeTab, setActiveTab] = React.useState("tv");
  const toggleTab = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };
  //   const [popOverOpen, SetPopOver] = useState(false);
  const [currentData, setCurrentData] = useState([]);

  const [state, setState] = useState({
    data: currentData,
    limit: 6,
    startIndex: 0,
    pageSize: currentData.length / 3,
    activePage: 1,
  });

  useEffect(() => {
    const data = [];
    const TabwiseData = ProductList.filter((element) => {
      return element.category === activeTab;
    });
    TabwiseData.filter((item, index) => {
      //   console.log(index, state.limit);
      if (index >= state.startIndex && data.length < state.limit) {
        data.push(item);
      }
    });
    setCurrentData(data);
  }, []);
  useEffect(() => {}, [currentData]);
  useEffect(() => {
    const TabwiseData = ProductList.filter((element) => {
      return element.category === activeTab;
    });
    setCurrentData(TabwiseData);
  }, [activeTab]);

  function toggle(index) {
    const data = [...currentData];
    const set = data[index].popOverOpen;
    data[index].popOverOpen = !set;
    setCurrentData(data);
    // SetPopOver(!popOverOpen);
  }

  const onHover = (index) => {
    const data = [...currentData];
    data[index].popOverOpen = true;
    setCurrentData(data);
    // SetPopOver(true);
  };

  const onHoverLeave = (index) => {
    const data = [...currentData];
    data[index].popOverOpen = false;
    setCurrentData(data);
    // SetPopOver(false);
  };
  const handlePageChange = (pageNumber) => {
    let sindex = 0;
    if (pageNumber !== 1) sindex = (pageNumber - 1) * state.limit;
    else sindex = 0;

    const data = [];
    currentData.map((item, index) => {
      if (index >= sindex && data.length < state.limit) {
        data.push(item);
      }
    });

    setState((prev) => ({
      ...prev,
      activePage: pageNumber,
      startIndex: sindex,
    }));
    setCurrentData(data);
  };

  return (
    <div className="section section-navigation">
      <Container className="tim-container" fluid="md">
        {/* <h2 className="mt-5 px-4">React Bootstrap pagination example</h2> */}
        <Col md="12">
          <div className="title">
            <h3>Category Sports</h3>
          </div>
          <div className="nav-tabs-navigation">
            <div className="nav-tabs-wrapper">
              <Nav id="tabs" role="tablist" tabs>
                <NavItem>
                  <NavLink
                    className={activeTab === "tv" ? "active" : ""}
                    onClick={() => {
                      toggleTab("tv");
                    }}
                  >
                    1
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "refrigrator" ? "active" : ""}
                    onClick={() => {
                      toggleTab("refrigrator");
                    }}
                  >
                    2
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink
                    className={activeTab === "computer" ? "active" : ""}
                    onClick={() => {
                      toggleTab("computer");
                    }}
                  >
                    3
                  </NavLink>
                </NavItem>
              </Nav>
            </div>
          </div>
          <TabContent activeTab={activeTab} className="text-center">
            <TabPane tabId={activeTab}>
              <Row md="3" sm="2" xs="1">
                {currentData.map((item, index) => {
                  return (
                    <>
                    <NavLink tag={Link} to="/task">
                
                      <Col>
                        <div
                          className="title shadow p-3 mb-5 border rounded-end rounded"
                          style={{ backgroundColor: "#d6d6d6" }}
                        >
                          {/* <h3>Navigation Areas</h3> */}
                          <Button
                            style={{
                              backgroundColor: "#d6d6d6",
                              border: "none",
                            }}
                            id={`btn-${item.id}`}
                            // onMouseEnter={(e) => {
                            //   onHover(index);
                            // }}
                            // onMouseLeave={(e) => {
                            //   onHoverLeave(index);
                            // }}
                          >
                            <div
                              class="card"
                              style={{ width: "15rem", display: "contents" }}
                            >
                              {item.image ? (
                                <img
                                  src={require(`assets/img/sports/${item.image}`)}
                                  class="card-img-top"
                                  alt="..."
                                />
                              ) : (
                                <img
                                  src="https://images.unsplash.com/photo-1533228100845-08145b01de14?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=438&q=80"
                                  class="card-img-top"
                                  alt="..."
                                />
                              )}

                              <div class="card-body">
                                <p class="card-text fw-bold">
                                  {item.desc}
                                </p>
                              </div>
                            </div>{" "}
                          </Button>
                        </div>
                      </Col>
                      
              </NavLink>
                      <Popover
                        placement="right"
                        target={`btn-${item.id}`}
                        isOpen={item.popOverOpen}
                        toggle={toggle}
                      >
                        <PopoverHeader>{item.name}</PopoverHeader>
                        <PopoverBody>
                          <TableBody />
                        </PopoverBody>
                      </Popover>
                    </>
                  );
                })}
              </Row>
            </TabPane>
          </TabContent>
        </Col>

        <div className="d-flex justify-content-center">
          <Pagination
            activePage={state.activePage}
            itemsCountPerPage={state.limit}
            totalItemsCount={currentData.length}
            pageRangeDisplayed={currentData.length / state.limit + 1}
            onChange={handlePageChange}
          />
        </div>
      </Container>
    </div>
  );
}
