
import React from "react";

import LightNavBar from "components/Navbars/LightNavBar.js";
import IndexHeader from "components/Headers/IndexHeader.js";
import DemoFooter from "components/Footers/DemoFooter.js";
import "./styleContact.css";
import SectionNucleoIcons from "views/index-sections/SectionNucleoIcons.js";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAt, faPhoneVolume } from "@fortawesome/free-solid-svg-icons";
import {
  faFacebook,
  faInstagram,
  faSquareInstagram,
} from "@fortawesome/free-brands-svg-icons";
import {} from "@fortawesome/fontawesome-svg-core";
import { fagma } from "@fortawesome/free-regular-svg-icons";
import { Card, CardTitle, CardText, Button, Row, Col } from "reactstrap";

function ContactUsPage() {
  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("index");
    return function cleanup() {
      document.body.classList.remove("index");
    };
  });
  return (
    <>
      <LightNavBar />
      <section id="thehero">
        <div class="the-inner">
          <div class="container">
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                {/* <h1>
                  A Company with a Culture More Relevant Than our Competitors
                  Culture
                </h1> */}
                <img
                  alt="..."
                  class="img-fluid"
                  src={require("assets/img/Hack.jpg")}
                />
              </div>
            </div>
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <p>
                  We now work in a hut facing the sea on the coast of{" "}
                  <a href="https://goo.gl/maps/M6EysMwYazF2">
                    Pattaya City, Thailand.
                  </a>{" "}
                  The stock image behind this block is what we think a real
                  agency hut should look like. We have over 10 years of
                  experience as digital nomads (we basically coined the term)
                  our team is projected to stay in more than seven various
                  countries as an expat in the next twenty years.
                </p>
              </div>
            </div>
            <Row md="4" sm="2" xs="1">
              <Col>
                <Card
                  body
                  className="text-center"
                  style={{
                    width: "auto",
                    backgroundColor: "#f1f1f1ba",
                  }}
                >
                  <CardTitle tag="h5">
                    <FontAwesomeIcon
                      icon={faFacebook}
                      size="6x"
                      color="#dc3545"
                    ></FontAwesomeIcon>
                  </CardTitle>
                  <CardText className="mt-4">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </CardText>
                  <Button color="primary">Go somewhere</Button>
                </Card>
              </Col>
              <Col>
                <Card
                  body
                  className="text-center"
                  style={{
                    width: "auto",
                    backgroundColor: "#f1f1f1ba",
                  }}
                >
                  <CardTitle tag="h5">
                    <FontAwesomeIcon
                      icon={faPhoneVolume}
                      size="6x"
                      color="#dc3545"
                    ></FontAwesomeIcon>
                  </CardTitle>
                  <CardText className="mt-4">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </CardText>
                  <Button color="primary">Go somewhere</Button>
                </Card>{" "}
              </Col>
              <Col>
                <Card
                  body
                  className="text-center"
                  style={{
                    width: "auto",
                    backgroundColor: "#f1f1f1ba",
                  }}
                >
                  <CardTitle tag="h5">
                    <FontAwesomeIcon
                      icon={faSquareInstagram}
                      color="#dc3545"
                      size="6x"
                    ></FontAwesomeIcon>
                  </CardTitle>
                  <CardText className="mt-4">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </CardText>
                  <Button color="primary">Go somewhere</Button>
                </Card>{" "}
              </Col>
              <Col>
                <Card
                  body
                  className="text-center"
                  style={{
                    width: "auto",
                    backgroundColor: "#f1f1f1ba",
                  }}
                >
                  <CardTitle tag="h5">
                    <FontAwesomeIcon
                      icon={faAt}
                      color="#dc3545"
                      size="6x"
                    ></FontAwesomeIcon>
                  </CardTitle>
                  <CardText className="mt-4">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </CardText>
                  <Button color="primary">Go somewhere</Button>
                </Card>
              </Col>
            </Row>

            {/* <div class="row points">
              <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-md-offset-.5">
                <p>Available After Midnight</p>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-md-offset-.5">
                <p>100% Apple & Mac</p>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-md-offset-.5">
                <p>TLDs With .io Only</p>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-md-offset-.5">
                <p>Support Via Slack</p>
              </div>
            </div> */}
          </div>
        </div>
      </section>
      <SectionNucleoIcons />
      <DemoFooter />
    </>
  );
}

export default ContactUsPage;
